var searchData=
[
  ['spanish_5fstem',['spanish_stem',['../classstemming_1_1spanish__stem.html',1,'stemming']]],
  ['stem',['stem',['../classstemming_1_1stem.html',1,'stemming']]],
  ['stemming',['stemming',['../namespacestemming.html',1,'stemming'],['../group___stemming.html',1,'(Global Namespace)']]],
  ['swedish_5fstem',['swedish_stem',['../classstemming_1_1swedish__stem.html',1,'stemming']]]
];
