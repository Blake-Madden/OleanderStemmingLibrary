var searchData=
[
  ['danish_5fstem',['danish_stem',['../classstemming_1_1danish__stem.html',1,'stemming']]],
  ['dutch_5fstem',['dutch_stem',['../classstemming_1_1dutch__stem.html',1,'stemming']]]
];
