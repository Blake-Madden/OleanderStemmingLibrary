var searchData=
[
  ['finnish_5fstem',['finnish_stem',['../classstemming_1_1finnish__stem.html',1,'stemming']]],
  ['french_5fstem',['french_stem',['../classstemming_1_1french__stem.html',1,'stemming']]]
];
