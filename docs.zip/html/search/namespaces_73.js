var searchData=
[
  ['stemming',['stemming',['../namespacestemming.html',1,'']]]
];
