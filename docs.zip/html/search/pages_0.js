var searchData=
[
  ['oleander_20stemming_20library',['Oleander Stemming Library',['../index.html',1,'']]]
];
