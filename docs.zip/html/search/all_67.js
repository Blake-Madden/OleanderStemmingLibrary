var searchData=
[
  ['german_5fstem',['german_stem',['../classstemming_1_1german__stem.html',1,'stemming']]]
];
