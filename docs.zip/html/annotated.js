var annotated =
[
    [ "stemming", "namespacestemming.html", "namespacestemming" ]
];