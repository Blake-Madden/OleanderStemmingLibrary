var classstemming_1_1finnish__stem =
[
    [ "operator()", "classstemming_1_1finnish__stem.html#a6d24a65f2ac78e047cc4ae17ffc6cf4f", null ]
];