var classstemming_1_1italian__stem =
[
    [ "operator()", "classstemming_1_1italian__stem.html#ae03dfb74685978fcc70c51b39b476218", null ]
];