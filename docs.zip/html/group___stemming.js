var group___stemming =
[
    [ "stemming", "namespacestemming.html", null ]
];