var classstemming_1_1norwegian__stem =
[
    [ "operator()", "classstemming_1_1norwegian__stem.html#ad8a84a0e802a365dda7581117957ac18", null ]
];