var classstemming_1_1spanish__stem =
[
    [ "operator()", "classstemming_1_1spanish__stem.html#a9af6d868041f401664b77fb9fc9b68a8", null ]
];