var classstemming_1_1german__stem =
[
    [ "operator()", "classstemming_1_1german__stem.html#a1a87bb26b9aafbab9219ac4b99f3147c", null ]
];