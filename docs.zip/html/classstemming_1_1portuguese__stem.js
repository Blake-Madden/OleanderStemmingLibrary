var classstemming_1_1portuguese__stem =
[
    [ "operator()", "classstemming_1_1portuguese__stem.html#a6f3e947191f331d34659ed2bb8e1f1ad", null ]
];