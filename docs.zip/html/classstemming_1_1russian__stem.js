var classstemming_1_1russian__stem =
[
    [ "operator()", "classstemming_1_1russian__stem.html#aff44c5969cffb3d7a5edac1b921a7514", null ]
];