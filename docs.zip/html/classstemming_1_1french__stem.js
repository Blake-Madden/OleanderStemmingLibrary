var classstemming_1_1french__stem =
[
    [ "operator()", "classstemming_1_1french__stem.html#abdb45c1e1e2dc0733398157d453c6ab6", null ]
];