var classstemming_1_1english__stem =
[
    [ "operator()", "classstemming_1_1english__stem.html#a8163a8cc4186b749665d616cbf11c492", null ]
];