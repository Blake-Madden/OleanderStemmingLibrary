var annotated_dup =
[
    [ "stemming", "namespacestemming.html", "namespacestemming" ]
];