var classstemming_1_1dutch__stem =
[
    [ "operator()", "classstemming_1_1dutch__stem.html#a0fce6efd2ae2e62a33a61b31ac88430c", null ]
];