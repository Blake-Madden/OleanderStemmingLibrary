var classstemming_1_1stem =
[
    [ "stem", "classstemming_1_1stem.html#a7f18c7b77cbfd7216805fea971ab70b7", null ]
];