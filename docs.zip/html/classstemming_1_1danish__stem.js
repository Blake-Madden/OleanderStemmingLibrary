var classstemming_1_1danish__stem =
[
    [ "operator()", "classstemming_1_1danish__stem.html#a66e40ae729f2371ff602bb756fefa64e", null ]
];