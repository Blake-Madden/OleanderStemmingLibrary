var classstemming_1_1swedish__stem =
[
    [ "operator()", "classstemming_1_1swedish__stem.html#a1d1d31e77726364b04f361b9076cbb48", null ]
];