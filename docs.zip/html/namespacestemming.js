var namespacestemming =
[
    [ "danish_stem", "classstemming_1_1danish__stem.html", "classstemming_1_1danish__stem" ],
    [ "dutch_stem", "classstemming_1_1dutch__stem.html", "classstemming_1_1dutch__stem" ],
    [ "english_stem", "classstemming_1_1english__stem.html", "classstemming_1_1english__stem" ],
    [ "finnish_stem", "classstemming_1_1finnish__stem.html", "classstemming_1_1finnish__stem" ],
    [ "french_stem", "classstemming_1_1french__stem.html", "classstemming_1_1french__stem" ],
    [ "german_stem", "classstemming_1_1german__stem.html", "classstemming_1_1german__stem" ],
    [ "italian_stem", "classstemming_1_1italian__stem.html", "classstemming_1_1italian__stem" ],
    [ "norwegian_stem", "classstemming_1_1norwegian__stem.html", "classstemming_1_1norwegian__stem" ],
    [ "portuguese_stem", "classstemming_1_1portuguese__stem.html", "classstemming_1_1portuguese__stem" ],
    [ "russian_stem", "classstemming_1_1russian__stem.html", "classstemming_1_1russian__stem" ],
    [ "spanish_stem", "classstemming_1_1spanish__stem.html", "classstemming_1_1spanish__stem" ],
    [ "stem", "classstemming_1_1stem.html", null ],
    [ "swedish_stem", "classstemming_1_1swedish__stem.html", "classstemming_1_1swedish__stem" ]
];