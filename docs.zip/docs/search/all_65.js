var searchData=
[
  ['english_5fstem',['english_stem',['../classstemming_1_1english__stem.html',1,'stemming']]]
];
