var searchData=
[
  ['stemming',['Stemming',['../group___stemming.html',1,'']]]
];
