var searchData=
[
  ['italian_5fstem',['italian_stem',['../classstemming_1_1italian__stem.html',1,'stemming']]]
];
