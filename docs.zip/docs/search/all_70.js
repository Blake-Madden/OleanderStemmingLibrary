var searchData=
[
  ['portuguese_5fstem',['portuguese_stem',['../classstemming_1_1portuguese__stem.html',1,'stemming']]]
];
