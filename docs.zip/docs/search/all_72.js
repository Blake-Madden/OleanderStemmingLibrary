var searchData=
[
  ['russian_5fstem',['russian_stem',['../classstemming_1_1russian__stem.html',1,'stemming']]]
];
