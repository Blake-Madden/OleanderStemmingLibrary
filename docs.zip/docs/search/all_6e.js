var searchData=
[
  ['norwegian_5fstem',['norwegian_stem',['../classstemming_1_1norwegian__stem.html',1,'stemming']]]
];
