var searchData=
[
  ['hash_5fdutch_5fyi',['hash_dutch_yi',['../group___stemming.html#gad7324f61a80140d122da1c087289b737',1,'stemming::stem']]],
  ['hash_5ffrench_5fyui',['hash_french_yui',['../group___stemming.html#ga0fa77155cef02f4efa2a537450ef4004',1,'stemming::stem']]],
  ['hash_5fgerman_5fyu',['hash_german_yu',['../group___stemming.html#ga2ab335f89cb2e65564a7985156d6ce19',1,'stemming::stem']]],
  ['hash_5fitalian_5fui',['hash_italian_ui',['../group___stemming.html#ga11d05105fc3e03bd5f2ff581bc4eb6fe',1,'stemming::stem']]]
];
