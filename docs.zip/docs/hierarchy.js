var hierarchy =
[
    [ "stemming::stem< string_typeT >", "classstemming_1_1stem.html", [
      [ "stemming::danish_stem< string_typeT >", "classstemming_1_1danish__stem.html", null ],
      [ "stemming::dutch_stem< string_typeT >", "classstemming_1_1dutch__stem.html", null ],
      [ "stemming::english_stem< string_typeT >", "classstemming_1_1english__stem.html", null ],
      [ "stemming::finnish_stem< string_typeT >", "classstemming_1_1finnish__stem.html", null ],
      [ "stemming::french_stem< string_typeT >", "classstemming_1_1french__stem.html", null ],
      [ "stemming::german_stem< string_typeT >", "classstemming_1_1german__stem.html", null ],
      [ "stemming::italian_stem< string_typeT >", "classstemming_1_1italian__stem.html", null ],
      [ "stemming::norwegian_stem< string_typeT >", "classstemming_1_1norwegian__stem.html", null ],
      [ "stemming::portuguese_stem< string_typeT >", "classstemming_1_1portuguese__stem.html", null ],
      [ "stemming::russian_stem< string_typeT >", "classstemming_1_1russian__stem.html", null ],
      [ "stemming::spanish_stem< string_typeT >", "classstemming_1_1spanish__stem.html", null ],
      [ "stemming::swedish_stem< string_typeT >", "classstemming_1_1swedish__stem.html", null ]
    ] ]
];