var annotated =
[
    [ "stemming", "namespacestemming.html", null ]
];