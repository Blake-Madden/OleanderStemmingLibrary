var namespaces =
[
    [ "stemming", "namespacestemming.html", null ]
];