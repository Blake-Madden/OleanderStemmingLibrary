var modules =
[
    [ "Stemming", "group___stemming.html", "group___stemming" ]
];